# Banking System Simulator — Microservices (Phase 2)

**Submitted by: Chaitanya Vijay Chaaudhari**

Services included:
- eureka-server (8761)
- api-gateway (8080)
- account-service (8081) — MongoDB
- transaction-service (8082) — MongoDB, Feign, Resilience4j
- notification-service (8083)

Build & Run (quick):
  - mvn -DskipTests clean package (in each service)
  - docker-compose up --build (from repo root)
