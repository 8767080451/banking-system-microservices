package com.bank.account.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.bank.account.model.Account;

public interface AccountRepository extends MongoRepository<Account, String> {
    Account findByAccountNumber(String accountNumber);
}
