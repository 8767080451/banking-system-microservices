package com.bank.account.controller;

import org.springframework.web.bind.annotation.*;
import com.bank.account.model.Account;
import com.bank.account.repository.AccountRepository;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountRepository repo;
    public AccountController(AccountRepository repo){this.repo=repo;}
    @PostMapping
    public Account create(@RequestBody Account a){ return repo.save(a); }
    @GetMapping("/{accountNumber}")
    public Account get(@PathVariable String accountNumber){ return repo.findByAccountNumber(accountNumber); }
    @GetMapping
    public List<Account> all(){ return repo.findAll(); }
    @PutMapping("/{accountNumber}/balance/{amount}")
    public Account updateBalance(@PathVariable String accountNumber, @PathVariable double amount){
        Account acc = repo.findByAccountNumber(accountNumber);
        if(acc==null) return null;
        acc.setBalance(acc.getBalance() + amount);
        return repo.save(acc);
    }
}
