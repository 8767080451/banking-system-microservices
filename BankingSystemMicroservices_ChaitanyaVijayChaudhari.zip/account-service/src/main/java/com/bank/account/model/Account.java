package com.bank.account.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "accounts")
public class Account {
    @Id
    private String id;
    private String accountNumber;
    private String holderName;
    private double balance;
    private String status;
    public Account() {}
    public String getId(){return id;}
    public void setId(String id){this.id=id;}
    public String getAccountNumber(){return accountNumber;}
    public void setAccountNumber(String a){this.accountNumber=a;}
    public String getHolderName(){return holderName;}
    public void setHolderName(String h){this.holderName=h;}
    public double getBalance(){return balance;}
    public void setBalance(double b){this.balance=b;}
    public String getStatus(){return status;}
    public void setStatus(String s){this.status=s;}
}
