package com.bank.notification.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    @PostMapping("/send")
    public String send(@RequestBody java.util.Map<String,String> body){
        String msg = body.getOrDefault("message","(empty)"); System.out.println("[Notification] "+msg); return "SENT: "+msg;
    }
}
