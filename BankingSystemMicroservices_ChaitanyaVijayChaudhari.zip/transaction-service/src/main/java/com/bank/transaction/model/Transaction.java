package com.bank.transaction.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "transactions")
public class Transaction {
    @Id
    private String id;
    private String transactionId;
    private String type;
    private double amount;
    private LocalDateTime timestamp;
    private String status;
    private String sourceAccount;
    private String destinationAccount;
    public Transaction() {}
    public String getTransactionId(){return transactionId;}
    public void setTransactionId(String t){this.transactionId=t;}
    public String getType(){return type;} public void setType(String t){this.type=t;}
    public double getAmount(){return amount;} public void setAmount(double a){this.amount=a;}
    public LocalDateTime getTimestamp(){return timestamp;} public void setTimestamp(LocalDateTime ts){this.timestamp=ts;}
    public String getStatus(){return status;} public void setStatus(String s){this.status=s;}
    public String getSourceAccount(){return sourceAccount;} public void setSourceAccount(String s){this.sourceAccount=s;}
    public String getDestinationAccount(){return destinationAccount;} public void setDestinationAccount(String d){this.destinationAccount=d;}
}
