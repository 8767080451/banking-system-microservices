package com.bank.transaction.service;

import com.bank.transaction.client.AccountClient;
import com.bank.transaction.client.NotificationClient;
import com.bank.transaction.model.Transaction;
import com.bank.transaction.repository.TransactionRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class TransactionService {
    private final TransactionRepository repo;
    private final AccountClient accountClient;
    private final NotificationClient notificationClient;
    public TransactionService(TransactionRepository repo, AccountClient accountClient, NotificationClient notificationClient){
        this.repo=repo; this.accountClient=accountClient; this.notificationClient=notificationClient;
    }
    @CircuitBreaker(name="accountService", fallbackMethod="depositFallback")
    public Transaction deposit(String accountNumber, double amount){
        Transaction t = new Transaction();
        t.setTransactionId("TXN-"+UUID.randomUUID().toString().substring(0,8));
        t.setType("DEPOSIT"); t.setAmount(amount); t.setTimestamp(LocalDateTime.now());
        accountClient.updateBalance(accountNumber, amount);
        t.setStatus("SUCCESS"); t.setSourceAccount(accountNumber);
        repo.save(t);
        try{ notificationClient.sendNotification(java.util.Map.of("message","Deposit of "+amount+" to "+accountNumber)); }catch(Exception ex){}
        return t;
    }
    public Transaction depositFallback(String accountNumber, double amount, Throwable th){
        Transaction t = new Transaction();
        t.setTransactionId("TXN-"+UUID.randomUUID().toString().substring(0,8));
        t.setType("DEPOSIT"); t.setAmount(amount); t.setTimestamp(LocalDateTime.now()); t.setStatus("FAILED"); t.setSourceAccount(accountNumber);
        repo.save(t); return t;
    }
}
