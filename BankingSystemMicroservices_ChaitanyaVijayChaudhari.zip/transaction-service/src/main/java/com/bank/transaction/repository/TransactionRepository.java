package com.bank.transaction.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.bank.transaction.model.Transaction;
import java.util.List;

public interface TransactionRepository extends MongoRepository<Transaction, String> {
    List<Transaction> findBySourceAccount(String sourceAccount);
}
