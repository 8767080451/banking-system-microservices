package com.bank.transaction.controller;

import com.bank.transaction.model.Transaction;
import com.bank.transaction.repository.TransactionRepository;
import com.bank.transaction.service.TransactionService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
    private final TransactionService service;
    private final TransactionRepository repo;
    public TransactionController(TransactionService service, TransactionRepository repo){this.service=service; this.repo=repo;}
    @PostMapping("/deposit")
    public Transaction deposit(@RequestBody Transaction t){ return service.deposit(t.getSourceAccount(), t.getAmount()); }
    @GetMapping("/account/{acc}")
    public List<Transaction> byAccount(@PathVariable String acc){ return repo.findBySourceAccount(acc); }
}
